import ast
from collections import defaultdict
from ohos.parser import *
from ohos.executor.bean import StackStateRecorder
import xml.etree.ElementTree as ET
from xdevice import *

__all__ = ["OHCJUnitPrefixes", "OHCJUnitTestListParser"]

LOG = platform_logger("OHCJUnitPrefixes")


class OHCJUnitPrefixes(Enum):
    SUM = "OHOS_REPORT_SUM: "
    STATUS = "OHOS_REPORT_STATUS: "
    STATUS_CODE = "OHOS_REPORT_STATUS_CODE: "
    RESULT = "OHOS_REPORT_RESULT: "
    CODE = "OHOS_REPORT_CODE: "
    TEST_FINISHED_RESULT_MSG = "TestFinished-ResultMsg: "
    COVERAGE_PATH = "OHOS_REPORT_COVERAGE_PATH: "
    WORKER_STATUS = "OHOS_REPORT_WORKER_STATUS: "


class OHCJUnitItemConstants(Enum):
    CLASS = "class"
    TEST = "test"
    NUM_TESTS = "numtests"
    STACK = "stack"
    STREAM = "stream"
    SUITE_CONSUMING = "suiteconsuming"
    CONSUMING = "consuming"
    APP_DIED = "App died"


@Plugin(type=Plugin.PARSER, id=CommonParserType.oh_cjunit)
class OHCJUnitPrefixes(IParser):

    def __init__(self):
        self.state_machine = StackStateRecorder()
        self.suites_name = ""
        self.listeners = []
        self.cur_sum = -1
        self.runner = None
        self.result_data = ""
        self.listener_result_info_tuple = None
        self.test_suite_line = ""
        self.current_test_suite_result = ""
        self.test_suite_flag = False
        # message from test output, the 'TestFinished-ResultMsg'
        self.__test_finish_result_msg = ""
        self.test_suites_run_time = 0

    def get_suite_name(self):
        return self.suites_name

    def get_listeners(self):
        return self.listeners

    def set_test_finish_result_msg(self, msg: str):
        self.__test_finish_result_msg = msg

    def __process__(self, lines):
        for line in lines:
            line = str(line).strip().rstrip("\r")
            LOG.debug(line)
            self.parse(line)

    def remove_skipped_testcases(self, xml_string):
        to_remove = []
        for testcase in xml_string.findall('testcase'):
            if testcase.find('skipped') is not None:
                to_remove.append(testcase)

        for tc in to_remove:
            xml_string.remove(tc)

        test_count = int(xml_string.get('tests'))
        skipped_count = int(xml_string.get('skipped'))

        xml_string.set('tests', str(test_count - len(to_remove)))
        xml_string.set('skipped', str(skipped_count - len(to_remove)))

        return ET.tostring(xml_string, encoding='unicode')

    def process_test_xml(self, xml_input: str) -> str:
        xml_str = f"<root>{xml_input}</root>"
        root = ET.fromstring(xml_str)
        suites = root.findall("testsuite")

        processed_suites = []

        for suite in suites:
            suite_name = suite.get("name").replace("default.", "")
            suite.set("name", suite_name)

            for testcase in list(suite.findall("testcase")):
                testcase_classname = testcase.get("classname").replace("default.", "")
                testcase.set("classname", testcase_classname)

                if testcase.find("skipped") is not None:
                    suite.remove(testcase)
                    tests = int(suite.get("tests", "0")) - 1
                    skipped = int(suite.get("skipped", "0")) - 1
                    suite.set("tests", str(tests))
                    suite.set("skipped", str(skipped))
                    continue

                failure = testcase.find("failure")
                if failure is not None:
                    text_parts = []
                    if failure.text:
                        text_parts.append(failure.text.strip())
                    for child in failure:
                        if child.text:
                            text_parts.append(child.text.strip())
                        if child.tail:
                            text_parts.append(child.tail.strip())
                    clean_text = ' '.join(' '.join(text_parts).split())

                    failure.text = clean_text
                    for child in list(failure):
                        failure.remove(child)

            tests = int(suite.get("tests", "0"))
            failures = int(suite.get("failures", "0"))
            errors = int(suite.get("errors", "0"))
            skipped = int(suite.get("skipped", "0"))
            time = float(suite.get("time", "0.0"))
            timestamp = suite.get("timestamp", "")

            processed_suites.append({
                "name": suite_name,
                "timestamp": timestamp,
                "tests": tests,
                "failures": failures,
                "errors": errors,
                "skipped": skipped,
                "time": time,
                "testcases": list(suite.findall("testcase"))
            })

        merged = defaultdict(lambda: {
            "name": "",
            "timestamp": "",
            "tests": 0,
            "failures": 0,
            "errors": 0,
            "skipped": 0,
            "time": 0.0,
            "testcases": []
        })

        for suite_info in processed_suites:
            name = suite_info["name"]
            merged[name]["name"] = name
            if not merged[name]["timestamp"]:
                merged[name]["timestamp"] = suite_info["timestamp"]
            merged[name]["tests"] += suite_info["tests"]
            merged[name]["failures"] += suite_info["failures"]
            merged[name]["errors"] += suite_info["errors"]
            merged[name]["skipped"] += suite_info["skipped"]
            merged[name]["time"] += suite_info["time"]
            merged[name]["testcases"].extend(suite_info["testcases"])

        final_root = ET.Element("testsuites")
        for name, data in merged.items():
            suite = ET.SubElement(final_root, "testsuite")
            suite.set("name", data["name"])
            suite.set("tests", str(data["tests"]))
            suite.set("failures", str(data["failures"]))
            suite.set("errors", str(data["errors"]))
            suite.set("skipped", str(data["skipped"]))
            suite.set("time", f"{data['time']:.6f}")
            suite.set("timestamp", data["timestamp"])

            for tc in data["testcases"]:
                testcase = ET.SubElement(suite, "testcase")
                for attr in tc.attrib:
                    testcase.set(attr, tc.get(attr))

                for child in tc:
                    if child.tag == "failure":
                        ET.SubElement(testcase, "failure").text = child.text

        return ET.tostring(final_root, encoding="unicode", method="xml")

    def get_testsuite(self, xml_str):
        root = ET.fromstring(xml_str)
        test_suites = []
        for testsuite in root.findall('testsuite'):
            test_suites.append({
                'element': testsuite,
                'xml_string': ET.tostring(testsuite, encoding='unicode', method='xml'),
                'attributes': dict(testsuite.attrib),
            })
        return test_suites

    def parse(self, line):
        if not str(line).strip():
            return
        if ("user test finished" in line):
            suites = self.state_machine.current_suite_list
            self.xmlParse(self.test_suite_line)
            for listener in self.get_listeners():
                listener.__ended__(LifeCycle.TestSuites, suites, suites_name=self.suites_name, message=self.__test_finish_result_msg)
            return

        else:
            if ("""<?xml version="1.0" encoding="UTF-8"?>""" in line):
                self.test_suite_flag = True
                return
            if (self.test_suite_flag and "EXECUTE_CLASS_END" not in line):
                self.test_suite_line = "%s%s" % (self.test_suite_line, line + "\n")

            if ('EXECUTE_CLASS_END' in line):
                self.test_suite_flag = False
                return
            else:
                return

    def xmlParse(self, xml_string):
        xmlRoot = self.process_test_xml(xml_string)
        for testsuiteValue in self.get_testsuite(xmlRoot):
            self.cur_sum = int(testsuiteValue['element'].attrib.get('tests'))
            self.current_test_suite_result = self.parse_test_results(testsuiteValue['xml_string'])
            self.state_machine.running_test_index = 0

            current_suite = self.state_machine.suite(reset=True)
            current_suite.test_num = self.cur_sum
            current_suite.suite_name = testsuiteValue['element'].attrib.get('name').replace('default.', '')
            self.state_machine.current_suite = current_suite

            for listener in self.get_listeners():
                suite = copy.copy(current_suite)
                listener.__started__(LifeCycle.TestSuite, suite)
            current_suite.is_started = True

            for testCase in self.current_test_suite_result:
                test_result = self.state_machine.test(reset=True)
                test_result.test_class = testCase['classname']
                test_result.test_name = testCase['name']
                test_result.stacktrace = testCase['stacktrace']
                test_result.num_tests = 1
                test_result.run_time = float(testCase['time'])
                test_result.current = self.state_machine.running_test_index + 1
                if (testCase['result']) == 'pass':
                    test_result.code = 0
                elif (testCase['result']) == 'fail':
                    test_result.code = 1
                elif (testCase['result']) == 'blocked':
                    test_result.code = -1
                elif (testCase['result']) == 'skipped':
                    test_result.code = 2
                elif (testCase['result']) == 'unavailable':
                    test_result.code = 3
                else:
                    test_result.code = -1010
                test_result = copy.copy(test_result)
                if (test_result.code == 2):
                    continue
                for listener in self.get_listeners():
                    listener.__started__(LifeCycle.TestCase, test_result)
                test_result = copy.copy(test_result)
                for listener in self.get_listeners():
                    listener.__ended__(LifeCycle.TestCase, test_result)

                self.state_machine.running_test_index += 1

            current_suite.run_time = float(testsuiteValue['element'].attrib.get('time'))
            self.test_suites_run_time += current_suite.run_time
            current_suite.is_completed = True
            for listener in self.get_listeners():
                suite = copy.copy(current_suite)
                listener.__ended__(LifeCycle.TestSuite, suite, is_clear=True)

    def parse_test_results(self, xml_content):
        root = ET.fromstring(xml_content)
        testcases = []

        for testcase in root.findall('testcase'):
            name = testcase.get('name')
            time = testcase.get('time')
            classname = testcase.get('classname').replace('default.', '')

            result = 'pass'
            stacktrace = ''

            failure = testcase.find('failure')
            if failure is not None:
                result = 'fail'
                stacktrace = failure.text
            else:
                skip = testcase.find('skipped')
                if skip is not None:
                    result = 'skip'
                    stacktrace = skip.text if skip.text else ''

            testcases.append({
                'name': name,
                'time': time,
                'classname': classname,
                'result': result,
                'stacktrace': stacktrace
            })

        return testcases

    @classmethod
    def output_stack_trace(cls, test_info):
        if check_pub_key_exist():
            return
        if test_info.stacktrace:
            stack_lines = test_info.stacktrace.split(r"\r\n")
            LOG.error("Stacktrace information is:")
            for line in stack_lines:
                line.strip()
                if line:
                    LOG.error(line)

    @staticmethod
    def check_legality(name):
        if not name or name == "null":
            return False
        return True

    def __done__(self):
        pass

    def notify_task_finished(self, finish_msg: str = ""):
        self.set_test_finish_result_msg(finish_msg)

    @classmethod
    def _is_target_listener(cls, listener):
        return listener.__class__.__name__ == "StackReportListener"


@Plugin(type=Plugin.PARSER, id=CommonParserType.oh_cjunit_list)
class OHCJUnitTestListParser(IParser):
    def __init__(self):
        self.tests = []
        self.json_str = ""
        self.tests_dict = dict()
        self.result_data = ""

    def __process__(self, lines):
        for line in lines:
            line = str(line).strip().rstrip("\r")
            self.result_data = "{}{}".format(self.result_data, line)
            self.parse(line)

    def __done__(self):
        LOG.debug("OHCJTestListParser data:")
        LOG.debug(self.result_data)
        self.result_data = ""

    def xml_to_test_json(self, xml_content):
        if isinstance(xml_content, str) and xml_content.strip().startswith('<'):
            xml_content = f"<root>{xml_content}</root>"
            root = ET.fromstring(xml_content)
        else:
            tree = ET.parse(xml_content)
            root = tree.getroot()

        result = {"suites": []}
        for testsuite in root.findall("testsuite"):
            suite_name = testsuite.attrib.get("name", "").replace("default.", "")
            case_list = []
            for testcase in testsuite.findall("testcase"):
                case_name = testcase.attrib.get("name", "")
                case_list.append({"itName": case_name})
            result["suites"].append({suite_name: case_list})
        return result

    def parse(self, line):
        if "<testsuite" in line or "<testcase" in line or "</testsuite>" in line or "<failure" in line or "</failure>" in line:
            self.json_str = "%s%s" % (self.json_str, line)
            return
        if "user test finished" in line:
            self.json_str = str(self.xml_to_test_json(self.json_str))
            suite_dict_list = ast.literal_eval(self.json_str).get("suites", [])
            for suite_dict in suite_dict_list:
                for class_name, test_name_dict_list in suite_dict.items():
                    self.tests_dict.update({class_name.strip(): []})
                    for test_name_dict in test_name_dict_list:
                        for test_name in test_name_dict.values():
                            test = TestDescription(class_name.strip(), test_name.strip())
                            self.tests_dict.get(class_name.strip()).append(test)
                            self.tests.append(test)
